package com.movietkt.booking.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.movietkt.booking.entity.Movie;
import com.movietkt.booking.repository.MovieRepository;
import com.movietkt.booking.service.MovieService;

@Service
public class MovieServiceImpl implements MovieService {

    @Autowired
    private MovieRepository movieRepository;

    @Override
    public Page<Movie> getAllMovies(int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("releaseDate").descending());
        return movieRepository.findAll(pageable);
    }

    @Override
    public Page<Movie> getMoviesByGenre(String genre, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("title").ascending());
        return movieRepository.findByGenre(genre, pageable);
    }

    @Override
    public Page<Movie> searchMovies(String keyword, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return movieRepository.findByTitleContainingIgnoreCase(keyword, pageable);
    }

    @Override
    public Page<Movie> getMoviesByRating(Double minRating, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("rating").descending());
        return movieRepository.findByRatingGreaterThanEqual(minRating, pageable);
    }

    @Override
    public Movie getMovieById(Long id) {
        return movieRepository.findById(id).orElse(null);
    }

    @Override
    public Movie saveMovie(Movie movie) {
        return movieRepository.save(movie);
    }

    @Override
    public void deleteMovie(Long id) {
        movieRepository.deleteById(id);
    }

    @Override
    public List<String> getAllGenres() {
        return movieRepository.findDistinctGenres();
    }
}