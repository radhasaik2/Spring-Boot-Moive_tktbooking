package com.movietkt.booking.service;

import com.movietkt.booking.entity.Movie;

import java.util.List;

import org.springframework.data.domain.Page;

public interface MovieService {
    Page<Movie> getAllMovies(int page, int size);
    Page<Movie> getMoviesByGenre(String genre, int page, int size);
    Page<Movie> searchMovies(String keyword, int page, int size);
    Page<Movie> getMoviesByRating(Double minRating, int page, int size);
    Movie getMovieById(Long id);
    Movie saveMovie(Movie movie);
    void deleteMovie(Long id);
    List<String> getAllGenres();
}