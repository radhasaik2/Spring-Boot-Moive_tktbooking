<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html>
<head>
    <title>Movies</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .movie-card {
            transition: transform 0.3s;
            height: 100%;
        }
        .movie-card:hover {
            transform: translateY(-5px);
        }
        .poster-img {
            height: 300px;
            object-fit: cover;
        }
        .rating-badge {
            position: absolute;
            top: 10px;
            right: 10px;
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <h1 class="text-center mb-4">🎬 Movie Collection</h1>
        
        <!-- Search Form -->
        <div class="row mb-4">
            <div class="col-md-8 mx-auto">
                <form action="${pageContext.request.contextPath}/movies/search" method="get" class="d-flex">
                    <input type="text" name="keyword" class="form-control me-2" placeholder="Search movies..." value="${param.keyword}">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-search"></i> Search
                    </button>
                    <a href="${pageContext.request.contextPath}/movies" class="btn btn-outline-secondary ms-2">
                        <i class="fas fa-times"></i> Clear
                    </a>
                </form>
            </div>
        </div>

        <!-- Genre Filter -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="d-flex flex-wrap gap-2">
                    <c:forEach var="genre" items="${genres}">
                        <a href="${pageContext.request.contextPath}/movies/genre/${genre}?page=0" 
                           class="btn btn-outline-info btn-sm ${selectedGenre == genre ? 'active' : ''}">
                            ${genre}
                        </a>
                    </c:forEach>
                </div>
            </div>
        </div>

        <!-- Movies Grid -->
        <div class="row">
            <c:forEach var="movie" items="${movies}">
                <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                    <div class="card movie-card shadow-sm">
                        <div class="position-relative">
                            <img src="${movie.posterUrl}" class="card-img-top poster-img" alt="${movie.title}">
                            <span class="rating-badge badge bg-warning text-dark">
                                <i class="fas fa-star"></i> ${movie.rating}
                            </span>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">${movie.title}</h5>
                            <p class="card-text">
                                <small class="text-muted">
                                    <i class="fas fa-language"></i> ${movie.language} | 
                                    <i class="fas fa-clock"></i> ${movie.duration} mins
                                </small>
                            </p>
                            <p class="card-text">
                                <span class="badge bg-primary">${movie.genre}</span>
                            </p>
                            <p class="card-text small text-truncate">${movie.description}</p>
                            <a href="${pageContext.request.contextPath}/movies/${movie.id}" class="btn btn-outline-primary btn-sm">
                                View Details
                            </a>
                        </div>
                    </div>
                </div>
            </c:forEach>
        </div>

        <!-- Pagination -->
        <c:if test="${totalPages > 1}">
            <nav aria-label="Movie pagination">
                <ul class="pagination justify-content-center">
                    <!-- Previous Page -->
                    <li class="page-item ${currentPage == 0 ? 'disabled' : ''}">
                        <a class="page-link" 
                           href="${pageContext.request.contextPath}/movies?page=${currentPage - 1}&size=${pageSize}${not empty keyword ? '&keyword=' += keyword : ''}${not empty selectedGenre ? '&genre=' += selectedGenre : ''}">
                            Previous
                        </a>
                    </li>
                    
                    <!-- Page Numbers -->
                    <c:forEach begin="0" end="${totalPages - 1}" var="i">
                        <li class="page-item ${currentPage == i ? 'active' : ''}">
                            <a class="page-link" 
                               href="${pageContext.request.contextPath}/movies?page=${i}&size=${pageSize}${not empty keyword ? '&keyword=' += keyword : ''}${not empty selectedGenre ? '&genre=' += selectedGenre : ''}">
                                ${i + 1}
                            </a>
                        </li>
                    </c:forEach>
                    
                    <!-- Next Page -->
                    <li class="page-item ${currentPage >= totalPages - 1 ? 'disabled' : ''}">
                        <a class="page-link" 
                           href="${pageContext.request.contextPath}/movies?page=${currentPage + 1}&size=${pageSize}${not empty keyword ? '&keyword=' += keyword : ''}${not empty selectedGenre ? '&genre=' += selectedGenre : ''}">
                            Next
                        </a>
                    </li>
                </ul>
            </nav>
        </c:if>

        <!-- Page Info -->
        <div class="text-center mt-3">
            <p class="text-muted">
                Showing ${currentPage * pageSize + 1} to 
                ${(currentPage + 1) * pageSize > totalItems ? totalItems : (currentPage + 1) * pageSize} 
                of ${totalItems} movies
            </p>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>