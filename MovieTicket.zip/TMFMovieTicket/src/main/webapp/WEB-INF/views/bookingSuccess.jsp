<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<div class="container mt-4 text-center">
    <h2> Booking Confirmed!</h2>
    <p>Your booking ID: <strong>${booking.id}</strong></p>
    <p>Total Paid: Rs. ${booking.amount}</p>
    <p>Status: ${booking.status}</p>
    <a href="${pageContext.request.contextPath}/booking/history-test" class="btn btn-secondary mt-3">View Booking History</a>
</div>