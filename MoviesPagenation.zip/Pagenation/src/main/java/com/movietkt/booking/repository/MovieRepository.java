package com.movietkt.booking.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.movietkt.booking.entity.Movie;

@Repository
public interface MovieRepository extends JpaRepository<Movie, Long> {
    
    // Find movies by genre with pagination
    Page<Movie> findByGenre(String genre, Pageable pageable);
    
    // Find movies by language with pagination
    Page<Movie> findByLanguage(String language, Pageable pageable);
    
    // Search movies by title containing keyword
    @Query("SELECT m FROM Movie m WHERE LOWER(m.title) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    Page<Movie> findByTitleContainingIgnoreCase(@Param("keyword") String keyword, Pageable pageable);
    
    // Find movies by rating greater than
    Page<Movie> findByRatingGreaterThanEqual(Double rating, Pageable pageable);
    
    // Get all movies sorted by release date
    Page<Movie> findAllByOrderByReleaseDateDesc(Pageable pageable);
    
    // Get distinct genres
    @Query("SELECT DISTINCT m.genre FROM Movie m WHERE m.genre IS NOT NULL")
    List<String> findDistinctGenres();
}