<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<div class="container mt-4">
    <h2>Confirm Booking</h2>
    <p>Booking ID: <strong>${booking.id}</strong></p>
    <p>Show Time: <strong>${booking.show.showTime}</strong></p>
    <p>Total Amount: Rs. ${booking.amount}</p>
    <p>Status: ${booking.status}</p>

    <form method="post" action="${pageContext.request.contextPath}/booking/confirm">
        <input type="hidden" name="bookingId" value="${booking.id}"/>
        <button class="btn btn-success">Confirm & Pay</button>
    </form>
</div>