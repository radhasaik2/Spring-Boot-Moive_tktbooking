<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<div class="container mt-4 text-center">
    <h2>Make Payment</h2>
    <p>Booking ID: <strong>${booking.id}</strong></p>
    <p>Amount to Pay: Rs. ${booking.amount}</p>
    <p>Payment ID: ${payment.id}</p>
    <p>Status: ${payment.status}</p>

    <form id="paymentForm" method="post" action="${pageContext.request.contextPath}/booking/confirm">
        <input type="hidden" name="bookingId" value="${booking.id}"/>
        <button type="button" id="payButton" class="btn btn-success">Pay Now</button>
    </form>
</div>

<script>
    document.getElementById('payButton').addEventListener('click', function() {
        alert('Processing payment...');
        
        // Simulate payment processing
        setTimeout(() => {
            // Call webhook to mark payment as successful
            fetch('${pageContext.request.contextPath}/payment/webhook', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    status: 'payment_success', 
                    txn_id: '${payment.txnId}'
                })
            }).then(response => {
                if (response.ok) {
                    // Submit the form to confirm booking
                    document.getElementById('paymentForm').submit();
                } else {
                    alert('Payment failed. Please try again.');
                }
            });
        }, 2000);
    });
</script>